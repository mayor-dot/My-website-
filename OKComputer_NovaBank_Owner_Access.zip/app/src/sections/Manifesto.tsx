import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const Manifesto = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const line1Ref = useRef<HTMLDivElement>(null);
  const line2Ref = useRef<HTMLDivElement>(null);
  const line3Ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const line1 = line1Ref.current;
    const line2 = line2Ref.current;
    const line3 = line3Ref.current;

    if (!section || !line1 || !line2 || !line3) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=150%',
          pin: true,
          scrub: 0.5,
        },
      });

      // Entrance animation
      scrollTl
        .fromTo(
          line1,
          { x: '-100%', opacity: 0 },
          { x: '0%', opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          line2,
          { x: '100%', opacity: 0 },
          { x: '0%', opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          line3,
          { x: '-100%', opacity: 0 },
          { x: '0%', opacity: 1, ease: 'none' },
          0
        )
        // Hold for reading
        .to({}, { duration: 0.4 })
        // Exit animation
        .to(
          [line1, line2, line3],
          {
            scale: 1.5,
            opacity: 0,
            filter: 'blur(10px)',
            ease: 'none',
          },
          0.6
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0B0E1E]"
    >
      {/* Background gradient */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#00D4FF]/5 rounded-full blur-[200px]" />
      </div>

      {/* Kinetic Typography */}
      <div className="relative z-10 w-full section-padding">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col items-center gap-4 sm:gap-6">
            <div
              ref={line1Ref}
              className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold text-white tracking-tighter whitespace-nowrap"
            >
              YOUR <span className="gradient-text">MONEY</span>
            </div>
            <div
              ref={line2Ref}
              className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold text-white tracking-tighter whitespace-nowrap"
            >
              YOUR <span className="gradient-text">CONTROL</span>
            </div>
            <div
              ref={line3Ref}
              className="text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-bold text-white tracking-tighter whitespace-nowrap"
            >
              YOUR <span className="gradient-text">FUTURE</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Manifesto;
