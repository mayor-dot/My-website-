import { Twitter, Linkedin, Instagram, Github, Mail, MapPin, Phone } from 'lucide-react';

const Footer = () => {
  const footerLinks = {
    Product: [
      { label: 'Features', href: '#' },
      { label: 'Pricing', href: '#' },
      { label: 'Security', href: '#security' },
      { label: 'Business', href: '#' },
      { label: 'Cards', href: '#cards' },
    ],
    Company: [
      { label: 'About Us', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Press', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Contact', href: '#' },
    ],
    Resources: [
      { label: 'Help Center', href: '#' },
      { label: 'Community', href: '#' },
      { label: 'Developers', href: '#' },
      { label: 'API Docs', href: '#' },
      { label: 'Status', href: '#' },
    ],
    Legal: [
      { label: 'Privacy Policy', href: '#' },
      { label: 'Terms of Service', href: '#' },
      { label: 'Cookie Policy', href: '#' },
      { label: 'Licenses', href: '#' },
      { label: 'Compliance', href: '#' },
    ],
  };

  const socialLinks = [
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Github, href: '#', label: 'GitHub' },
  ];

  return (
    <footer className="relative bg-[#0B0E1E] border-t border-white/5">
      {/* Main Footer */}
      <div className="section-padding py-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
            {/* Brand Column */}
            <div className="col-span-2 md:col-span-3 lg:col-span-2">
              <a href="#" className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00D4FF] to-[#7B2FF7] flex items-center justify-center">
                  <span className="text-white font-bold text-lg">N</span>
                </div>
                <span className="text-white font-semibold text-xl">
                  Nova<span className="text-[#00D4FF]">Bank</span>
                </span>
              </a>
              <p className="text-[#8A94B0] text-sm mb-6 max-w-xs">
                The future of banking is here. Secure, seamless, and designed for 
                your digital lifestyle.
              </p>
              
              {/* Contact Info */}
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-sm text-[#8A94B0]">
                  <Mail className="w-4 h-4 text-[#00D4FF]" />
                  <span>support@novabank.com</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-[#8A94B0]">
                  <Phone className="w-4 h-4 text-[#00D4FF]" />
                  <span>+1 (888) NOVA-BANK</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-[#8A94B0]">
                  <MapPin className="w-4 h-4 text-[#00D4FF]" />
                  <span>San Francisco, CA</span>
                </div>
              </div>
            </div>

            {/* Link Columns */}
            {Object.entries(footerLinks).map(([category, links]) => (
              <div key={category}>
                <h4 className="text-white font-semibold mb-4">{category}</h4>
                <ul className="space-y-3">
                  {links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        className="text-sm text-[#8A94B0] hover:text-[#00D4FF] transition-colors duration-300"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="section-padding py-6">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <div className="text-sm text-[#8A94B0]">
              © {new Date().getFullYear()} NovaBank. All rights reserved.
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full glass-card flex items-center justify-center text-[#8A94B0] hover:text-[#00D4FF] hover:bg-[#00D4FF]/10 transition-all duration-300"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>

            {/* Legal Text */}
            <div className="text-xs text-[#8A94B0]">
              NovaBank is a financial technology company, not a bank. Banking services 
              provided by our partner banks, Members FDIC.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
