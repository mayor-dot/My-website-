import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Fingerprint, Lock, Eye, ShieldCheck, AlertTriangle, Clock } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Security = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const image = imageRef.current;
    const features = featuresRef.current;

    if (!section || !content || !image || !features) return;

    const ctx = gsap.context(() => {
      // Content reveal animation
      gsap.fromTo(
        content.querySelectorAll('.animate-item'),
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Image reveal with rotation
      gsap.fromTo(
        image,
        { scale: 0.8, opacity: 0, rotateY: -30 },
        {
          scale: 1,
          opacity: 1,
          rotateY: 0,
          duration: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Continuous rotation on scroll
      gsap.to(image, {
        rotateY: 360,
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        },
      });

      // Features stagger
      gsap.fromTo(
        features.querySelectorAll('.feature-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: features,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const securityFeatures = [
    {
      icon: Fingerprint,
      title: 'Biometric Auth',
      description: 'Face ID and fingerprint login for instant, secure access',
    },
    {
      icon: Lock,
      title: '256-Bit Encryption',
      description: 'Military-grade encryption protects all your data',
    },
    {
      icon: Eye,
      title: 'Instant Card Freeze',
      description: 'Lost your card? Freeze it instantly with one tap',
    },
    {
      icon: ShieldCheck,
      title: 'FDIC Insured',
      description: 'Your deposits are insured up to $250,000',
    },
    {
      icon: AlertTriangle,
      title: 'Fraud Alerts',
      description: 'Real-time notifications for suspicious activity',
    },
    {
      icon: Clock,
      title: '24/7 Monitoring',
      description: 'Round-the-clock security team watching your back',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="security"
      className="relative py-24 sm:py-32 overflow-hidden bg-[#0B0E1E]"
    >
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#00D4FF]/5 rounded-full blur-[200px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#7B2FF7]/5 rounded-full blur-[150px]" />
      </div>

      <div className="relative z-10 section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Left Content */}
            <div ref={contentRef}>
              <div className="animate-item inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
                <ShieldCheck className="w-4 h-4 text-[#00D4FF]" />
                <span className="text-sm text-[#8A94B0]">Bank-Grade Security</span>
              </div>

              <h2 className="animate-item text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                Fort Knox in Your{' '}
                <span className="gradient-text">Pocket</span>
              </h2>

              <p className="animate-item text-lg text-[#8A94B0] mb-8 max-w-lg">
                We use the same 256-bit encryption standards as the world's leading 
                banks. Your data is yours, period. Sleep soundly knowing your 
                money is protected by military-grade security.
              </p>

              {/* Security Badge */}
              <div className="animate-item flex items-center gap-4 mb-10">
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-green-500/10 border border-green-500/20">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-sm text-green-400">All Systems Secure</span>
                </div>
                <div className="text-sm text-[#8A94B0]">
                  Last audit: <span className="text-white">Today</span>
                </div>
              </div>
            </div>

            {/* Right Content - Security Shield */}
            <div ref={imageRef} className="relative flex justify-center perspective-1000">
              <div className="relative w-[280px] sm:w-[350px] aspect-square">
                <img
                  src="/security-shield.jpg"
                  alt="Security Shield"
                  className="w-full h-full object-contain"
                />
                {/* Glow Effect */}
                <div className="absolute inset-0 bg-[#00D4FF]/20 rounded-full blur-[100px] -z-10" />
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div
            ref={featuresRef}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-20"
          >
            {securityFeatures.map((feature, index) => (
              <div
                key={index}
                className="feature-item glass-card rounded-2xl p-6 hover:bg-white/5 transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#00D4FF]/10 flex items-center justify-center mb-4 group-hover:bg-[#00D4FF]/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-[#00D4FF]" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-[#8A94B0]">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Security;
