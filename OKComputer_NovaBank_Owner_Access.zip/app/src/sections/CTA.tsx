import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Download, Star, Shield } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const CTA = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        content.querySelectorAll('.animate-item'),
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-24 sm:py-32 overflow-hidden bg-[#0B0E1E]"
    >
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-[#00D4FF]/15 to-transparent rounded-full blur-[100px]" />
        <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iNTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMCwgMjEyLCAyNTUsIDAuMDUpIi8+PC9zdmc+')] opacity-30" />
      </div>

      <div className="relative z-10 section-padding">
        <div className="max-w-4xl mx-auto">
          <div
            ref={contentRef}
            className="glass-card-strong rounded-3xl sm:rounded-[40px] p-8 sm:p-12 lg:p-16 text-center relative overflow-hidden"
          >
            {/* Decorative Elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#00D4FF]/10 rounded-full blur-[80px]" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#7B2FF7]/10 rounded-full blur-[60px]" />

            <div className="relative z-10">
              {/* Badge */}
              <div className="animate-item inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00D4FF]/10 border border-[#00D4FF]/20 mb-8">
                <Star className="w-4 h-4 text-[#00D4FF]" />
                <span className="text-sm text-[#00D4FF]">Join 2M+ happy customers</span>
              </div>

              {/* Headline */}
              <h2 className="animate-item text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white mb-6 leading-tight">
                Ready to Start Your{' '}
                <span className="gradient-text">Financial Journey?</span>
              </h2>

              {/* Subheadline */}
              <p className="animate-item text-lg text-[#8A94B0] mb-10 max-w-2xl mx-auto">
                Open your free account in minutes. No hidden fees, no minimum balance, 
                no credit check required. Experience banking that actually works for you.
              </p>

              {/* CTA Buttons */}
              <div className="animate-item flex flex-col sm:flex-row gap-4 justify-center mb-10">
                <button className="btn-primary flex items-center justify-center gap-2 group text-lg py-4 px-8">
                  Open Free Account
                  <ArrowRight
                    size={20}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </button>
                <button className="btn-outline flex items-center justify-center gap-2">
                  <Download size={20} />
                  Download App
                </button>
              </div>

              {/* Trust Badges */}
              <div className="animate-item flex flex-wrap justify-center gap-6 sm:gap-10">
                <div className="flex items-center gap-2 text-[#8A94B0]">
                  <Shield className="w-5 h-5 text-green-400" />
                  <span className="text-sm">256-bit Encryption</span>
                </div>
                <div className="flex items-center gap-2 text-[#8A94B0]">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Star
                        key={i}
                        className="w-4 h-4 text-yellow-400 fill-yellow-400"
                      />
                    ))}
                  </div>
                  <span className="text-sm">4.9 App Rating</span>
                </div>
                <div className="flex items-center gap-2 text-[#8A94B0]">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-sm">Instant Approval</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
