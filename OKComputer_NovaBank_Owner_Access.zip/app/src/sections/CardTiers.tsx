import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Star, Crown, Gem } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface CardTier {
  name: string;
  price: string;
  period: string;
  image: string;
  icon: React.ElementType;
  features: string[];
  highlighted: boolean;
  color: string;
}

const CardTiers = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsContainerRef = useRef<HTMLDivElement>(null);
  const [activeCard, setActiveCard] = useState(1);

  const cardTiers: CardTier[] = [
    {
      name: 'Standard',
      price: 'Free',
      period: 'forever',
      image: '/card-standard.jpg',
      icon: Star,
      features: [
        'Virtual & Physical Card',
        'Free Domestic Transfers',
        'Basic Analytics',
        '24/7 Support',
      ],
      highlighted: false,
      color: '#3B82F6',
    },
    {
      name: 'Premium',
      price: '$9.99',
      period: '/month',
      image: '/card-premium.jpg',
      icon: Crown,
      features: [
        'Everything in Standard',
        'Free International Transfers',
        'Advanced Analytics',
        'Priority Support',
        'Cashback Rewards',
      ],
      highlighted: true,
      color: '#00D4FF',
    },
    {
      name: 'Metal',
      price: '$19.99',
      period: '/month',
      image: '/card-metal.jpg',
      icon: Gem,
      features: [
        'Everything in Premium',
        'Premium Metal Card',
        'Concierge Service',
        'Lounge Access',
        'Higher Cashback',
        'Investment Tools',
      ],
      highlighted: false,
      color: '#A855F7',
    },
  ];

  useEffect(() => {
    const section = sectionRef.current;
    const cardsContainer = cardsContainerRef.current;

    if (!section || !cardsContainer) return;

    const cards = cardsContainer.querySelectorAll('.tier-card');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=150%',
          pin: true,
          scrub: 0.5,
        },
      });

      // Entrance - cards stack in
      scrollTl
        .fromTo(
          cardsContainer,
          { opacity: 0 },
          { opacity: 1, duration: 0.2 }
        )
        // Spread animation
        .to(
          cards[0],
          {
            x: '-120%',
            rotateY: -15,
            ease: 'none',
          },
          0.2
        )
        .to(
          cards[2],
          {
            x: '120%',
            rotateY: 15,
            ease: 'none',
          },
          0.2
        )
        // Hold
        .to({}, { duration: 0.3 })
        // Exit
        .to(
          cards,
          {
            opacity: 0,
            y: -100,
            ease: 'none',
          },
          0.8
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="cards"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0B0E1E]"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] bg-gradient-radial from-[#00D4FF]/10 to-transparent rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 w-full section-padding">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Choose Your <span className="gradient-text">Perfect Card</span>
            </h2>
            <p className="text-[#8A94B0] text-lg max-w-2xl mx-auto">
              From free essentials to premium perks, find the card that fits your lifestyle
            </p>
          </div>

          {/* Cards Container */}
          <div
            ref={cardsContainerRef}
            className="relative h-[500px] sm:h-[600px] perspective-1000"
          >
            <div className="absolute inset-0 flex items-center justify-center">
              {cardTiers.map((tier, index) => (
                <div
                  key={tier.name}
                  className={`tier-card absolute w-[280px] sm:w-[320px] transition-all duration-500 ${
                    activeCard === index ? 'z-30' : 'z-10'
                  }`}
                  style={{
                    transform: `translateX(${(index - 1) * 20}px)`,
                  }}
                  onMouseEnter={() => setActiveCard(index)}
                >
                  <div
                    className={`glass-card-strong rounded-3xl overflow-hidden transition-all duration-300 ${
                      tier.highlighted
                        ? 'ring-2 ring-[#00D4FF] shadow-lg shadow-[#00D4FF]/20'
                        : ''
                    } ${activeCard === index ? 'scale-105' : 'scale-100'}`}
                  >
                    {/* Card Image */}
                    <div className="relative h-[200px] sm:h-[240px]">
                      <img
                        src={tier.image}
                        alt={`${tier.name} Card`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E1E] to-transparent" />
                      
                      {/* Popular Badge */}
                      {tier.highlighted && (
                        <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-[#00D4FF] text-[#0B0E1E] text-xs font-semibold">
                          Most Popular
                        </div>
                      )}
                    </div>

                    {/* Card Content */}
                    <div className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{ backgroundColor: `${tier.color}20` }}
                        >
                          <tier.icon className="w-5 h-5" style={{ color: tier.color }} />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">{tier.name}</h3>
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-bold text-white">{tier.price}</span>
                            <span className="text-sm text-[#8A94B0]">{tier.period}</span>
                          </div>
                        </div>
                      </div>

                      <ul className="space-y-3 mb-6">
                        {tier.features.map((feature, i) => (
                          <li key={i} className="flex items-center gap-3">
                            <div
                              className="w-5 h-5 rounded-full flex items-center justify-center"
                              style={{ backgroundColor: `${tier.color}20` }}
                            >
                              <Check className="w-3 h-3" style={{ color: tier.color }} />
                            </div>
                            <span className="text-sm text-[#8A94B0]">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <button
                        className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${
                          tier.highlighted
                            ? 'bg-[#00D4FF] text-[#0B0E1E] hover:bg-[#00D4FF]/90'
                            : 'glass-card text-white hover:bg-white/10'
                        }`}
                      >
                        Get {tier.name}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mobile Card Selector */}
          <div className="flex justify-center gap-2 mt-8 md:hidden">
            {cardTiers.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveCard(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  activeCard === index ? 'w-6 bg-[#00D4FF]' : 'bg-white/20'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CardTiers;
