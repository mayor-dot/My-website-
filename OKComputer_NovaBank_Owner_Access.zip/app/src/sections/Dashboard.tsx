import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TrendingUp, ArrowUpRight, CreditCard, Wallet, PiggyBank } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Dashboard = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const mainCardRef = useRef<HTMLDivElement>(null);
  const chartCardRef = useRef<HTMLDivElement>(null);
  const listCardRef = useRef<HTMLDivElement>(null);
  const transferCardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const mainCard = mainCardRef.current;
    const chartCard = chartCardRef.current;
    const listCard = listCardRef.current;
    const transferCard = transferCardRef.current;

    if (!section || !mainCard || !chartCard || !listCard || !transferCard) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=200%',
          pin: true,
          scrub: 0.5,
        },
      });

      // Entrance animation - cards assemble from off-screen
      scrollTl
        .fromTo(
          mainCard,
          { y: '100vh', scale: 0.8, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          chartCard,
          { x: '50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.1
        )
        .fromTo(
          listCard,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.1
        )
        .fromTo(
          transferCard,
          { y: '50vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15
        )
        // Hold for viewing
        .to({}, { duration: 0.3 })
        // Exit animation - push into Z-space
        .to(
          [mainCard, chartCard, listCard, transferCard],
          {
            z: 500,
            scale: 0.5,
            opacity: 0,
            ease: 'none',
          },
          0.6
        );
    }, section);

    return () => ctx.revert();
  }, []);

  // Mouse parallax effect
  useEffect(() => {
    const section = sectionRef.current;
    const cards = [mainCardRef.current, chartCardRef.current, listCardRef.current, transferCardRef.current];
    
    if (!section) return;

    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      
      cards.forEach((card, index) => {
        if (!card) return;
        const factor = (index + 1) * 0.01;
        const x = (clientX - centerX) * factor;
        const y = (clientY - centerY) * factor;
        
        gsap.to(card, {
          x,
          y,
          duration: 0.5,
          ease: 'power2.out',
        });
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const transactions = [
    { name: 'Starbucks', amount: '-$5.50', icon: '☕', positive: false },
    { name: 'Salary Deposit', amount: '+$4,500', icon: '💰', positive: true },
    { name: 'Netflix', amount: '-$15.99', icon: '🎬', positive: false },
    { name: 'Uber', amount: '-$12.30', icon: '🚗', positive: false },
  ];

  return (
    <section
      ref={sectionRef}
      id="dashboard"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0B0E1E]"
    >
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 212, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 212, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full section-padding">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Your Financial <span className="gradient-text">Command Center</span>
            </h2>
            <p className="text-[#8A94B0] text-lg max-w-2xl mx-auto">
              Track, manage, and grow your money with our intuitive dashboard
            </p>
          </div>

          {/* Floating Cards */}
          <div className="relative h-[500px] sm:h-[600px] perspective-1000">
            {/* Main Balance Card */}
            <div
              ref={mainCardRef}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] sm:w-[400px] glass-card-strong rounded-3xl p-6 sm:p-8 z-20"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#00D4FF]/20 flex items-center justify-center">
                    <Wallet className="w-5 h-5 text-[#00D4FF]" />
                  </div>
                  <span className="text-[#8A94B0]">Total Balance</span>
                </div>
                <span className="text-[#00D4FF] text-sm">+2.4%</span>
              </div>
              <div className="text-4xl sm:text-5xl font-bold text-white mb-2">
                $24,500.00
              </div>
              <div className="flex items-center gap-2 text-sm text-[#8A94B0]">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span>+$580 this month</span>
              </div>

              {/* Mini Chart */}
              <div className="mt-6 h-24 flex items-end gap-1">
                {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 100].map((h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-t-sm bg-gradient-to-t from-[#00D4FF]/30 to-[#00D4FF]"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>

            {/* Chart Card */}
            <div
              ref={chartCardRef}
              className="absolute top-[10%] right-[5%] sm:right-[15%] w-[180px] sm:w-[220px] glass-card rounded-2xl p-4 z-10"
            >
              <div className="flex items-center gap-2 mb-3">
                <PiggyBank className="w-5 h-5 text-[#7B2FF7]" />
                <span className="text-sm text-[#8A94B0]">Savings Goal</span>
              </div>
              <div className="text-2xl font-bold text-white mb-2">$8,420</div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full w-[65%] bg-gradient-to-r from-[#7B2FF7] to-[#00D4FF] rounded-full" />
              </div>
              <div className="text-xs text-[#8A94B0] mt-2">65% of $13,000 goal</div>
            </div>

            {/* Transaction List Card */}
            <div
              ref={listCardRef}
              className="absolute top-[15%] left-[5%] sm:left-[10%] w-[200px] sm:w-[240px] glass-card rounded-2xl p-4 z-10"
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-[#8A94B0]">Recent</span>
                <ArrowUpRight className="w-4 h-4 text-[#8A94B0]" />
              </div>
              <div className="space-y-3">
                {transactions.slice(0, 3).map((tx, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{tx.icon}</span>
                      <span className="text-sm text-white">{tx.name}</span>
                    </div>
                    <span
                      className={`text-sm ${
                        tx.positive ? 'text-green-400' : 'text-white'
                      }`}
                    >
                      {tx.amount}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Transfer Card */}
            <div
              ref={transferCardRef}
              className="absolute bottom-[10%] right-[10%] sm:right-[20%] w-[160px] sm:w-[180px] glass-card rounded-2xl p-4 z-10"
            >
              <div className="flex items-center gap-2 mb-3">
                <CreditCard className="w-5 h-5 text-[#00D4FF]" />
                <span className="text-sm text-[#8A94B0]">Quick Send</span>
              </div>
              <div className="flex -space-x-2">
                {['JD', 'MK', 'SL', '+'].map((initial, i) => (
                  <div
                    key={i}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium border-2 border-[#0B0E1E] ${
                      i === 3
                        ? 'bg-[#00D4FF]/20 text-[#00D4FF]'
                        : 'bg-gradient-to-br from-[#00D4FF] to-[#7B2FF7] text-white'
                    }`}
                  >
                    {initial}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;
