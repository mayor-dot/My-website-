import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Globe, Send, Landmark, Smartphone, ArrowRightLeft, Wallet } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const GlobalReach = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;
    const map = mapRef.current;
    const stats = statsRef.current;

    if (!section || !content || !map || !stats) return;

    const ctx = gsap.context(() => {
      // Content reveal
      gsap.fromTo(
        content.querySelectorAll('.animate-item'),
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Map reveal with scale
      gsap.fromTo(
        map,
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 1.2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Map dots pulse animation
      gsap.to(map.querySelectorAll('.map-dot'), {
        opacity: 1,
        scale: 1.2,
        duration: 1.5,
        stagger: {
          each: 0.1,
          repeat: -1,
          yoyo: true,
        },
        ease: 'sine.inOut',
      });

      // Stats counter animation
      gsap.fromTo(
        stats.querySelectorAll('.stat-item'),
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: stats,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const features = [
    { icon: Send, label: 'Instant Transfers', desc: 'Send money in seconds' },
    { icon: ArrowRightLeft, label: 'Multi-Currency', desc: 'Hold 50+ currencies' },
    { icon: Landmark, label: 'Local Accounts', desc: 'Get local bank details' },
    { icon: Smartphone, label: 'Mobile First', desc: 'Bank from anywhere' },
    { icon: Wallet, label: 'Virtual Cards', desc: 'Create cards instantly' },
    { icon: Globe, label: 'Global Coverage', desc: '150+ countries' },
  ];

  const stats = [
    { value: '150+', label: 'Countries' },
    { value: '50+', label: 'Currencies' },
    { value: '0%', label: 'Hidden Fees' },
    { value: '<1min', label: 'Transfer Time' },
  ];

  return (
    <section
      ref={sectionRef}
      id="global"
      className="relative py-24 sm:py-32 overflow-hidden bg-[#0B0E1E]"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1200px] h-[1200px] bg-[#00D4FF]/5 rounded-full blur-[200px]" />
      </div>

      <div className="relative z-10 section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Left Content */}
            <div ref={contentRef}>
              <div className="animate-item inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
                <Globe className="w-4 h-4 text-[#00D4FF]" />
                <span className="text-sm text-[#8A94B0]">Global Banking</span>
              </div>

              <h2 className="animate-item text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                Global Banking,{' '}
                <span className="gradient-text">Local Feel</span>
              </h2>

              <p className="animate-item text-lg text-[#8A94B0] mb-8 max-w-lg">
                Send, spend, and receive money internationally with zero hidden fees. 
                Get local bank details in multiple currencies and transact like a local 
                wherever you go.
              </p>

              {/* Features Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10">
                {features.map((feature, index) => (
                  <div
                    key={index}
                    className="animate-item glass-card rounded-xl p-4 hover:bg-white/5 transition-all duration-300 group"
                  >
                    <feature.icon className="w-6 h-6 text-[#00D4FF] mb-2 group-hover:scale-110 transition-transform" />
                    <div className="text-sm font-medium text-white">{feature.label}</div>
                    <div className="text-xs text-[#8A94B0]">{feature.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Content - Map */}
            <div ref={mapRef} className="relative">
              <div className="relative aspect-video rounded-3xl overflow-hidden glass-card-strong">
                <img
                  src="/global-map.jpg"
                  alt="Global Network"
                  className="w-full h-full object-cover"
                />
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0E1E]/80 via-transparent to-[#0B0E1E]/40" />
                
                {/* Animated Dots */}
                <div className="absolute inset-0">
                  {[
                    { top: '30%', left: '20%' },
                    { top: '25%', left: '50%' },
                    { top: '35%', left: '75%' },
                    { top: '55%', left: '30%' },
                    { top: '60%', left: '60%' },
                    { top: '45%', left: '85%' },
                  ].map((pos, i) => (
                    <div
                      key={i}
                      className="map-dot absolute w-3 h-3"
                      style={{ top: pos.top, left: pos.left }}
                    >
                      <div className="absolute inset-0 rounded-full bg-[#00D4FF]" />
                      <div className="absolute inset-0 rounded-full bg-[#00D4FF] animate-ping opacity-50" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating Stats Card */}
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 glass-card-strong rounded-2xl p-4 sm:p-6 min-w-[280px] sm:min-w-[320px]">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-sm text-[#8A94B0]">Live Network Status</span>
                </div>
                <div className="grid grid-cols-4 gap-4 text-center">
                  {stats.map((stat, i) => (
                    <div key={i}>
                      <div className="text-lg sm:text-xl font-bold text-white">{stat.value}</div>
                      <div className="text-xs text-[#8A94B0]">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Stats */}
          <div
            ref={statsRef}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-24"
          >
            {[
              { value: '$2B+', label: 'Monthly Volume' },
              { value: '5M+', label: 'Happy Customers' },
              { value: '99.9%', label: 'Uptime' },
              { value: '4.9★', label: 'App Store Rating' },
            ].map((stat, i) => (
              <div key={i} className="stat-item text-center">
                <div className="text-3xl sm:text-4xl font-bold gradient-text mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-[#8A94B0]">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default GlobalReach;
