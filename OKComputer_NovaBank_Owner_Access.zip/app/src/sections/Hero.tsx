import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Shield, Zap, Globe } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const card = cardRef.current;
    const content = contentRef.current;
    const stats = statsRef.current;

    if (!section || !card || !content || !stats) return;

    const ctx = gsap.context(() => {
      // Initial load animation
      const loadTl = gsap.timeline({ delay: 0.3 });

      loadTl
        .fromTo(
          card,
          { opacity: 0, y: 100, rotateX: 45, scale: 0.8 },
          { opacity: 1, y: 0, rotateX: 0, scale: 1, duration: 1.2, ease: 'power3.out' }
        )
        .fromTo(
          content.querySelectorAll('.animate-item'),
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power2.out' },
          '-=0.6'
        )
        .fromTo(
          stats.querySelectorAll('.stat-item'),
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out' },
          '-=0.4'
        );

      // Card floating animation
      gsap.to(card, {
        y: -15,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=100%',
          pin: true,
          scrub: 0.5,
        },
      });

      scrollTl
        .to(card, {
          y: -200,
          rotateY: 30,
          scale: 0.8,
          opacity: 0,
          ease: 'none',
        })
        .to(
          content.querySelectorAll('.animate-item'),
          {
            y: -50,
            opacity: 0,
            stagger: 0.05,
            ease: 'none',
          },
          0
        )
        .to(
          stats,
          {
            y: -30,
            opacity: 0,
            ease: 'none',
          },
          0
        );
    }, section);

    return () => ctx.revert();
  }, []);

  // Mouse move effect for card tilt
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const rotateY = ((e.clientX - centerX) / rect.width) * 20;
      const rotateX = ((centerY - e.clientY) / rect.height) * 20;

      gsap.to(card, {
        rotateX,
        rotateY,
        duration: 0.5,
        ease: 'power2.out',
      });
    };

    const handleMouseLeave = () => {
      gsap.to(card, {
        rotateX: 0,
        rotateY: 0,
        duration: 0.5,
        ease: 'power2.out',
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/hero-bg.jpg"
          alt=""
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0E1E]/50 via-transparent to-[#0B0E1E]" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full section-padding">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Left Content */}
            <div ref={contentRef} className="text-center lg:text-left">
              <div className="animate-item inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-6">
                <span className="w-2 h-2 rounded-full bg-[#00D4FF] animate-pulse" />
                <span className="text-sm text-[#8A94B0]">Now available in 150+ countries</span>
              </div>

              <h1 className="animate-item text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white leading-tight mb-6">
                Banking for the{' '}
                <span className="gradient-text">Digital Age</span>
              </h1>

              <p className="animate-item text-lg text-[#8A94B0] max-w-xl mx-auto lg:mx-0 mb-8">
                Experience the future of finance with zero fees, instant transfers, 
                and unmatched security. Your money, your control, your future.
              </p>

              <div className="animate-item flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
                <button className="btn-primary flex items-center justify-center gap-2 group">
                  Open Free Account
                  <ArrowRight
                    size={18}
                    className="transition-transform duration-300 group-hover:translate-x-1"
                  />
                </button>
                <button className="btn-outline">Learn More</button>
              </div>

              {/* Stats */}
              <div
                ref={statsRef}
                className="flex flex-wrap justify-center lg:justify-start gap-8"
              >
                <div className="stat-item text-center lg:text-left">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">2M+</div>
                  <div className="text-sm text-[#8A94B0]">Active Users</div>
                </div>
                <div className="stat-item text-center lg:text-left">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">$10B+</div>
                  <div className="text-sm text-[#8A94B0]">Transactions</div>
                </div>
                <div className="stat-item text-center lg:text-left">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">4.9</div>
                  <div className="text-sm text-[#8A94B0]">App Rating</div>
                </div>
              </div>
            </div>

            {/* Right Content - 3D Card */}
            <div className="relative flex justify-center lg:justify-end perspective-1000">
              <div
                ref={cardRef}
                className="relative preserve-3d"
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* Main Card */}
                <div className="relative w-[280px] sm:w-[340px] aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl">
                  <img
                    src="/card-metal.jpg"
                    alt="NovaBank Metal Card"
                    className="w-full h-full object-cover"
                  />
                  {/* Card Glow */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#00D4FF]/20 to-transparent" />
                </div>

                {/* Floating Elements */}
                <div className="absolute -top-6 -right-6 glass-card-strong rounded-2xl p-4 animate-bounce">
                  <Shield className="w-8 h-8 text-[#00D4FF]" />
                </div>

                <div
                  className="absolute -bottom-4 -left-8 glass-card-strong rounded-2xl p-4"
                  style={{ animation: 'bounce 3s infinite 0.5s' }}
                >
                  <Zap className="w-8 h-8 text-[#00D4FF]" />
                </div>

                <div
                  className="absolute top-1/2 -right-12 glass-card-strong rounded-2xl p-4"
                  style={{ animation: 'bounce 3s infinite 1s' }}
                >
                  <Globe className="w-8 h-8 text-[#00D4FF]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
